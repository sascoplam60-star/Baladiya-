// src/types/employee.ts

export type DocStatus = "valid" | "expiring_soon" | "expired";

export type UserRole =
  | "super_admin"
  | "gr_department"
  | "operations_manager"
  | "area_manager";

// Stored at users/{uid} in Firestore. Determines what an authenticated
// user is allowed to see/do, enforced both client-side (for UX) and in
// firestore.rules (for real security).
export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  // Only relevant for operations_manager: the operation manager name(s)
  // they are scoped to. Used to filter employees.operationManager.
  operationManagerScope?: string[];
  // Only relevant for area_manager: the area manager name(s) they are
  // scoped to. Used to filter employees.areaManager.
  areaManagerScope?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface Employee {
  employeeId: string; // also the Firestore document ID
  employeeName: string;
  storeId: string;
  storeName: string;
  areaManager: string;
  operationManager: string;
  mobile: string;
  position: string;
  company: string;
  nationality: string;
  passportNumber: string;

  iqamaNumber: string;
  iqamaExpiry: string; // ISO date string, e.g. "2026-09-01"
  iqamaDaysLeft: number; // derived, recalculated on read/write
  iqamaStatus: DocStatus; // derived
  iqamaAvailable: boolean;

  baladiyaExpiry: string;
  baladiyaDaysLeft: number;
  baladiyaStatus: DocStatus;
  baladiyaCard: boolean;

  certificateExpiry: string;
  certificateDaysLeft: number;
  certificateStatus: DocStatus;

  medical: boolean;
  training: boolean;
  physicalCard: boolean;

  grAction: string;
  grUpdatedDate: string;

  // File storage paths/URLs (Firebase Storage download URLs)
  photoUrl?: string;
  passportCopyUrl?: string;
  iqamaCopyUrl?: string;
  baladiyaCardUrl?: string;
  certificateUrl?: string;
  medicalReportUrl?: string;
  trainingCertificateUrl?: string;

  createdAt: string;
  updatedAt: string;
}

// Fields a caller supplies when creating/editing; derived fields
// (daysLeft/status) are computed server-side by the service layer.
export type EmployeeInput = Omit<
  Employee,
  | "iqamaDaysLeft"
  | "iqamaStatus"
  | "baladiyaDaysLeft"
  | "baladiyaStatus"
  | "certificateDaysLeft"
  | "certificateStatus"
  | "createdAt"
  | "updatedAt"
>;

export interface EmployeeFilters {
  storeId?: string;
  areaManager?: string;
  operationManager?: string;
  company?: string;
  nationality?: string;
  position?: string;
  iqamaStatus?: DocStatus;
  baladiyaStatus?: DocStatus;
  certificateStatus?: DocStatus;
  medical?: boolean;
  training?: boolean;
  physicalCard?: boolean;
  searchTerm?: string; // matched client-side against name/id/store/iqama/passport/mobile
}
