// src/firebase/firestore.ts
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  QueryConstraint,
  serverTimestamp,
  Unsubscribe,
} from "firebase/firestore";
import { db } from "./config";
import {
  Employee,
  EmployeeInput,
  EmployeeFilters,
  UserProfile,
} from "@/types/employee";
import { deriveExpiry } from "@/utils/dateCalculations";

const EMPLOYEES_COLLECTION = "employees";

/** Recompute the derived days-left/status fields from expiry dates. */
function withDerivedFields(input: EmployeeInput) {
  const iqama = deriveExpiry(input.iqamaExpiry);
  const baladiya = deriveExpiry(input.baladiyaExpiry);
  const certificate = deriveExpiry(input.certificateExpiry);
  return {
    ...input,
    iqamaDaysLeft: iqama.daysLeft,
    iqamaStatus: iqama.status,
    baladiyaDaysLeft: baladiya.daysLeft,
    baladiyaStatus: baladiya.status,
    certificateDaysLeft: certificate.daysLeft,
    certificateStatus: certificate.status,
  };
}

export async function createEmployee(input: EmployeeInput): Promise<void> {
  const data = withDerivedFields(input);
  await setDoc(doc(db, EMPLOYEES_COLLECTION, input.employeeId), {
    ...data,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export async function updateEmployee(
  employeeId: string,
  input: Partial<EmployeeInput>
): Promise<void> {
  // Re-derive status fields if any expiry date changed.
  const patch: Record<string, unknown> = { ...input };
  if (input.iqamaExpiry) {
    const d = deriveExpiry(input.iqamaExpiry);
    patch.iqamaDaysLeft = d.daysLeft;
    patch.iqamaStatus = d.status;
  }
  if (input.baladiyaExpiry) {
    const d = deriveExpiry(input.baladiyaExpiry);
    patch.baladiyaDaysLeft = d.daysLeft;
    patch.baladiyaStatus = d.status;
  }
  if (input.certificateExpiry) {
    const d = deriveExpiry(input.certificateExpiry);
    patch.certificateDaysLeft = d.daysLeft;
    patch.certificateStatus = d.status;
  }
  patch.updatedAt = serverTimestamp();

  await updateDoc(doc(db, EMPLOYEES_COLLECTION, employeeId), patch);
}

export async function deleteEmployee(employeeId: string): Promise<void> {
  await deleteDoc(doc(db, EMPLOYEES_COLLECTION, employeeId));
}

export async function duplicateEmployee(
  sourceEmployeeId: string,
  newEmployeeId: string
): Promise<void> {
  const snap = await getDoc(doc(db, EMPLOYEES_COLLECTION, sourceEmployeeId));
  if (!snap.exists()) throw new Error("Source employee not found");
  const data = snap.data() as Employee;
  await setDoc(doc(db, EMPLOYEES_COLLECTION, newEmployeeId), {
    ...data,
    employeeId: newEmployeeId,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export async function getEmployee(employeeId: string): Promise<Employee | null> {
  const snap = await getDoc(doc(db, EMPLOYEES_COLLECTION, employeeId));
  return snap.exists() ? (snap.data() as Employee) : null;
}

/**
 * Builds Firestore query constraints for a user's role scope.
 * This mirrors firestore.rules and is applied client-side purely so the
 * UI only *requests* data the user is allowed to see (fewer reads) —
 * the rules are what actually enforce it.
 */
function scopeConstraintsForRole(profile: UserProfile): QueryConstraint[] {
  switch (profile.role) {
    case "super_admin":
    case "gr_department":
      return [];
    case "operations_manager":
      if (profile.operationManagerScope?.length) {
        return [where("operationManager", "in", profile.operationManagerScope)];
      }
      return [];
    case "area_manager":
      if (profile.areaManagerScope?.length) {
        return [where("areaManager", "in", profile.areaManagerScope)];
      }
      return [];
    default:
      return [];
  }
}

/** Builds Firestore query constraints from the filter panel selections. */
function filterConstraints(filters: EmployeeFilters): QueryConstraint[] {
  const constraints: QueryConstraint[] = [];
  if (filters.storeId) constraints.push(where("storeId", "==", filters.storeId));
  if (filters.areaManager) constraints.push(where("areaManager", "==", filters.areaManager));
  if (filters.operationManager)
    constraints.push(where("operationManager", "==", filters.operationManager));
  if (filters.company) constraints.push(where("company", "==", filters.company));
  if (filters.nationality) constraints.push(where("nationality", "==", filters.nationality));
  if (filters.position) constraints.push(where("position", "==", filters.position));
  if (filters.iqamaStatus) constraints.push(where("iqamaStatus", "==", filters.iqamaStatus));
  if (filters.baladiyaStatus)
    constraints.push(where("baladiyaStatus", "==", filters.baladiyaStatus));
  if (filters.certificateStatus)
    constraints.push(where("certificateStatus", "==", filters.certificateStatus));
  if (filters.medical !== undefined) constraints.push(where("medical", "==", filters.medical));
  if (filters.training !== undefined) constraints.push(where("training", "==", filters.training));
  if (filters.physicalCard !== undefined)
    constraints.push(where("physicalCard", "==", filters.physicalCard));
  return constraints;
}

/**
 * Realtime subscription to the employees list, scoped by role and
 * narrowed by the active filters. Free-text search (searchTerm) is applied
 * client-side after the snapshot arrives, since Firestore doesn't support
 * substring search natively.
 *
 * NOTE: combining role scope + multiple filter fields may require a
 * composite index — see firestore.indexes.json.
 */
export function subscribeToEmployees(
  profile: UserProfile,
  filters: EmployeeFilters,
  callback: (employees: Employee[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const constraints: QueryConstraint[] = [
    ...scopeConstraintsForRole(profile),
    ...filterConstraints(filters),
    orderBy("employeeName"),
  ];

  const q = query(collection(db, EMPLOYEES_COLLECTION), ...constraints);

  return onSnapshot(
    q,
    (snapshot) => {
      let results = snapshot.docs.map((d) => d.data() as Employee);

      if (filters.searchTerm) {
        const term = filters.searchTerm.toLowerCase();
        results = results.filter(
          (e) =>
            e.employeeName.toLowerCase().includes(term) ||
            e.employeeId.toLowerCase().includes(term) ||
            e.storeId.toLowerCase().includes(term) ||
            e.storeName.toLowerCase().includes(term) ||
            e.iqamaNumber.toLowerCase().includes(term) ||
            e.passportNumber.toLowerCase().includes(term) ||
            e.mobile.toLowerCase().includes(term)
        );
      }

      callback(results);
    },
    (error) => onError?.(error)
  );
}

/** One-off fetch (e.g. for export), same scoping/filtering as the subscription. */
export async function fetchEmployeesOnce(
  profile: UserProfile,
  filters: EmployeeFilters = {}
): Promise<Employee[]> {
  const constraints: QueryConstraint[] = [
    ...scopeConstraintsForRole(profile),
    ...filterConstraints(filters),
    orderBy("employeeName"),
  ];
  const snapshot = await getDocs(query(collection(db, EMPLOYEES_COLLECTION), ...constraints));
  return snapshot.docs.map((d) => d.data() as Employee);
}
