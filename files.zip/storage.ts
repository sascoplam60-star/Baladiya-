// src/firebase/storage.ts
import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  UploadTaskSnapshot,
} from "firebase/storage";
import { storage } from "./config";

export type DocumentType =
  | "photo"
  | "passportCopy"
  | "iqamaCopy"
  | "baladiyaCard"
  | "certificate"
  | "medicalReport"
  | "trainingCertificate";

/** Storage layout: employees/{employeeId}/{documentType}/{filename} */
function buildPath(employeeId: string, docType: DocumentType, fileName: string) {
  return `employees/${employeeId}/${docType}/${fileName}`;
}

/**
 * Uploads a file with progress reporting and resolves with its public
 * download URL once complete.
 */
export function uploadEmployeeFile(
  employeeId: string,
  docType: DocumentType,
  file: File,
  onProgress?: (percent: number) => void
): Promise<string> {
  const path = buildPath(employeeId, docType, file.name);
  const storageRef = ref(storage, path);
  const task = uploadBytesResumable(storageRef, file);

  return new Promise((resolve, reject) => {
    task.on(
      "state_changed",
      (snapshot: UploadTaskSnapshot) => {
        const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        onProgress?.(percent);
      },
      (error) => reject(error),
      async () => {
        const url = await getDownloadURL(task.snapshot.ref);
        resolve(url);
      }
    );
  });
}

export async function deleteEmployeeFile(
  employeeId: string,
  docType: DocumentType,
  fileName: string
): Promise<void> {
  const path = buildPath(employeeId, docType, fileName);
  await deleteObject(ref(storage, path));
}
