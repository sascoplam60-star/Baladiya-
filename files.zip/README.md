# Firebase layer — Employee Documents Management System

## What's here
```
src/types/employee.ts       Employee, UserProfile, filter types
src/utils/dateCalculations.ts   Days-left / status logic (Valid/Expiring/Expired)
src/firebase/config.ts      Firebase app init (reads env vars)
src/firebase/auth.ts        Sign in/out, user role profile lookup
src/firebase/firestore.ts   Employee CRUD + role-scoped realtime queries
src/firebase/storage.ts     Employee file uploads (photo, iqama, passport, etc.)
src/context/AuthContext.tsx React context exposing {user, profile, loading}
firestore.rules             Role-based read/write security rules
firestore.indexes.json      Composite indexes for the filter combinations used
storage.rules                Storage access rules (10MB upload cap)
.env.local.example           Env var template with your Firebase config
```

## 1. Install dependencies
```bash
npm install firebase react-hook-form
```

## 2. Environment variables
```bash
cp .env.local.example .env.local
```
Then add the same `NEXT_PUBLIC_FIREBASE_*` keys in Vercel → Project Settings →
Environment Variables (Production + Preview).

## 3. Enable Firebase products
In the Firebase Console for project `baladiya-d911d`:
- **Authentication** → enable Email/Password sign-in.
- **Firestore Database** → create in production mode.
- **Storage** → create default bucket (already referenced: `baladiya-d911d.firebasestorage.app`).

## 4. Provision your first Super Admin
Rules require a `users/{uid}` doc to exist before *any* Firestore access
works (including creating more users), so bootstrap the first one directly
in the Firebase Console:
1. Authentication → Add user (email + password) → copy the generated UID.
2. Firestore → create collection `users` → document ID = that UID:
   ```json
   {
     "uid": "<uid>",
     "email": "admin@yourcompany.com",
     "role": "super_admin",
     "createdAt": <timestamp>,
     "updatedAt": <timestamp>
   }
   ```
After that, use `createUserProfile()` from `src/firebase/auth.ts` (called
from a Super Admin–only screen) to provision GR Department, Operations
Manager, and Area Manager accounts — the latter two need
`operationManagerScope` / `areaManagerScope` arrays set to control what
they can see.

## 5. Deploy rules & indexes
```bash
npm install -g firebase-tools
firebase login
firebase use baladiya-d911d
firebase deploy --only firestore:rules,firestore:indexes,storage:rules
```

## 6. Deploy the app
```bash
vercel --prod
```
(Make sure the env vars from step 2 are set in Vercel first.)

## Notes
- `employeeId` is used as the Firestore document ID directly, per the spec.
- `iqamaDaysLeft`/`Status`, `baladiyaDaysLeft`/`Status`, and
  `certificateDaysLeft`/`Status` are recalculated by the service layer on
  every create/update — they're not meant to be hand-edited in forms.
  If you add a scheduled Cloud Function to recalc them daily (so status
  flips from "Valid" to "Expiring Soon" without anyone editing the record),
  reuse `deriveExpiry()` from `src/utils/dateCalculations.ts`.
- This package covers the **Firebase integration layer** only (auth,
  Firestore, Storage, rules, indexes) — not the Next.js pages/components
  (dashboard, tables, forms, charts). Happy to build those next if useful.
