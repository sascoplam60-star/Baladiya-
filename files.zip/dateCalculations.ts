// src/utils/dateCalculations.ts
import { DocStatus } from "@/types/employee";

/**
 * Days between today and an expiry date. Negative means already expired.
 */
export function calculateDaysLeft(expiryDate: string): number {
  if (!expiryDate) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  const diffMs = expiry.getTime() - today.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Status rules (identical for Iqama / Baladiya / Certificate):
 *  > 60 days left      -> valid
 *  1-60 days left       -> expiring_soon
 *  <= 0 days left        -> expired
 */
export function calculateStatus(daysLeft: number): DocStatus {
  if (daysLeft <= 0) return "expired";
  if (daysLeft <= 60) return "expiring_soon";
  return "valid";
}

/** Convenience: run both calculations at once for a given expiry date. */
export function deriveExpiry(expiryDate: string): {
  daysLeft: number;
  status: DocStatus;
} {
  const daysLeft = calculateDaysLeft(expiryDate);
  return { daysLeft, status: calculateStatus(daysLeft) };
}

export const STATUS_COLORS: Record<DocStatus, string> = {
  valid: "#16a34a", // green
  expiring_soon: "#eab308", // yellow
  expired: "#dc2626", // red
};

export const STATUS_LABELS: Record<DocStatus, string> = {
  valid: "Valid",
  expiring_soon: "Expiring Soon",
  expired: "Expired",
};
