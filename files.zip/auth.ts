// src/firebase/auth.ts
import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User,
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "./config";
import { UserProfile } from "@/types/employee";

export async function signIn(email: string, password: string): Promise<User> {
  const credential = await signInWithEmailAndPassword(auth, email, password);
  return credential.user;
}

export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

/** Subscribe to auth state changes. Returns the unsubscribe function. */
export function onAuthChange(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}

/**
 * Fetch the role/scope profile for a signed-in user from users/{uid}.
 * This document must be created by a Super Admin when provisioning a new
 * user (see createUserProfile below) — it is what firestore.rules checks
 * to decide what the user can read/write.
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const snap = await getDoc(doc(db, "users", uid));
  if (!snap.exists()) return null;
  return snap.data() as UserProfile;
}

/** Super Admin only — provisions the Firestore profile for a new user. */
export async function createUserProfile(
  uid: string,
  email: string,
  role: UserProfile["role"],
  scope?: Pick<UserProfile, "operationManagerScope" | "areaManagerScope">
): Promise<void> {
  await setDoc(doc(db, "users", uid), {
    uid,
    email,
    role,
    ...scope,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}
